[Copy the entire script above]
