# Contributing

- Enable hooks: bash scripts/setup-git-hooks.sh
- Do not commit files >50MB; use Git LFS or external storage.
- Open PRs to main; branch protection requires 1 approving review.